# Platzi Intelligence Agency Web
Part of Curso de Scrapy 🕷
